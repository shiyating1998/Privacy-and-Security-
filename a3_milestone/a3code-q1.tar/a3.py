import base64
import requests


message = "hello Nessie"
message_bytes = message.encode('ascii')
base64_bytes = base64.b64encode(message_bytes)
base64_message = base64_bytes.decode('ascii')

print("Message sent to Nessie:"+ base64_message)

# Question 1 part 1: send a message [3 marks]

# defining the api-endpoint
API_ENDPOINT = "https://hash-browns.cs.uwaterloo.ca/api/plain/send"

# your API key here
API_TOKEN = "0110d98bbd4388d7b9727e688e843b367a23024bc04f3795f7b1d23b8c1e1291"


# data to be sent to api
data = {'url': "https://hash-browns.cs.uwaterloo.ca",
        "Accept header": "application/json",
        "Content-Type header": "application/json",
        'api_token': API_TOKEN,
        'to': "Nessie", "message":  base64_message,
        }

# sending post request and saving response as response object
r = requests.post(url=API_ENDPOINT, data=data)



#Question 1 part 2: receive a message [2 marks]
url_response = "https://hash-browns.cs.uwaterloo.ca/api/plain/inbox"
# data to be sent to api
data = {'url': "https://hash-browns.cs.uwaterloo.ca",
        "Accept header": "application/json",
        "Content-Type header": "application/json",
        'api_token': API_TOKEN,
        }

# sending post request and saving response as response object
r = requests.post(url=url_response, data=data)

p = r.json()
#decode the message received from Nessie
base64_message = r.json()[0]['message']
base64_bytes = base64_message.encode('ascii')
message_bytes = base64.b64decode(base64_bytes)
message = message_bytes.decode('ascii')
print("The message received from Nessie:" + message)